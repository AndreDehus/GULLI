package control;

import io.NamedPipeIO.PipeActionEvent;

/**
 *
 * @author saemann
 */
public interface PipeActionListener {

    public void actionPerformed(PipeActionEvent ae);
}
