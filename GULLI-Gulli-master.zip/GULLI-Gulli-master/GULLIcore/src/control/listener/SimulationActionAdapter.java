/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control.listener;

/**
 *
 * @author saemann
 */
public class SimulationActionAdapter implements SimulationActionListener {

    @Override
    public void simulationINIT(Object caller) {
    }

    @Override
    public void simulationSTART(Object caller) {
    }

    @Override
    public void simulationSTEPFINISH(long loop,Object caller) {
    }

    @Override
    public void simulationPAUSED(Object caller) {
    }

    @Override
    public void simulationRESUMPTION(Object caller) {
    }

    @Override
    public void simulationSTOP(Object caller) {
    }

    @Override
    public void simulationFINISH(boolean timeOut, boolean particlesOut) {
    }

    @Override
    public void simulationRESET(Object caller) {
    }

}
