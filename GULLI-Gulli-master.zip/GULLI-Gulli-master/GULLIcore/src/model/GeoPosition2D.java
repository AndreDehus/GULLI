package model;

public interface GeoPosition2D {

	public double getLatitude();
	
	public double getLongitude();
}
